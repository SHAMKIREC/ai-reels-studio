# AI REELS STUDIO — MASTER SKILL

Цель: пользователь пишет только идею. Система сама превращает её в вертикальный ролик.

## Defaults
- 9:16, 1080×1920, 30 FPS
- 45–60 секунд
- русский язык по умолчанию
- современный editorial/tech motion
- не копировать конкретного автора или ролик 1:1; использовать только общие принципы ритма и визуальной грамматики

## Pipeline
1. IDEA — определить тезис, аудиторию, конфликт и обещание.
2. SCRIPT — hook 0–3с, контекст, развитие, вывод, финальный punchline.
3. STORYBOARD — разбить на смысловые биты 1–4с.
4. VISUAL — kinetic type, UI mockups, diagrams, cards, numbers, B-roll.
5. MOTION — spring/scale/position/opacity/masks/stagger; движение всегда служит смыслу.
6. PACING — визуальное изменение каждые 1–3с, без хаоса.
7. CAPTIONS — 2–5 слов в активной группе, акцентировать ключевые слова.
8. ASSETS — пользовательские материалы приоритетнее стока.
9. REMOTION — компоненты, presets, theme, frame-based animation.
10. REVIEW — проверить hook, pacing, readability, motion, consistency, ending.
11. PRESET MEMORY — удачные паттерны сохранять и переиспользовать.

## One-line command example
"Почему AI-агенты изменят создание контента"

После этого агент должен пройти весь pipeline и отдать финальный MP4.
