import path from 'node:path';
import fs from 'node:fs/promises';
import {bundle} from '@remotion/bundler';
import {renderMedia, selectComposition} from '@remotion/renderer';
import {makePlan} from './plan.mjs';

const idea = process.argv.slice(2).join(' ') || 'Почему AI-агенты изменят создание контента';
const plan = makePlan(idea);
const serveUrl = await bundle({entryPoint:path.resolve('src/index.ts')});
const composition = await selectComposition({serveUrl, id:'Reel', inputProps:{plan}});
await fs.mkdir('out',{recursive:true});
const safe = idea.toLowerCase().replace(/[^a-zа-я0-9]+/gi,'-').replace(/^-|-$/g,'').slice(0,40) || 'reel';
const outputLocation = path.resolve('out', `${safe}.mp4`);
await renderMedia({
  composition, serveUrl, codec:'h264', outputLocation, inputProps:{plan},
  chromiumOptions:{gl:'angle'}
});
console.log(outputLocation);
