const clean = (s) => String(s||'').replace(/\s+/g,' ').trim();

export function makePlan(idea){
  idea = clean(idea);
  const title = idea || 'Новая идея';
  const short = title.length > 72 ? title.slice(0,69)+'…' : title;
  return {
    title: short,
    accent: '#A8FF60',
    scenes: [
      {kicker:'ХУК', text: short, durationInFrames: 105, mode:'hero'},
      {kicker:'КОНТЕКСТ', text:'Почему это важно именно сейчас?', durationInFrames: 105, mode:'cards'},
      {kicker:'РАЗВОРОТ', text:'Не автоматизируй вкус. Автоматизируй рутину.', durationInFrames: 120, mode:'quote'},
      {kicker:'СИСТЕМА', text:'Идея → сценарий → сцены → motion → render', durationInFrames: 135, mode:'number'},
      {kicker:'ФИНАЛ', text:'Нейронка ускоряет. Решение всё ещё принимает человек.', durationInFrames: 120, mode:'hero'}
    ]
  };
}
