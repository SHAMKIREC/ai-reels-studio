import React from 'react';
import {AbsoluteFill, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {VideoPlan, Scene} from './types';

const SceneView: React.FC<{scene:Scene; accent:string}> = ({scene, accent}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const intro = spring({frame, fps, config:{damping:18, stiffness:160}});
  const y = interpolate(intro,[0,1],[70,0]);
  const opacity = interpolate(frame,[0,10],[0,1],{extrapolateRight:'clamp'});
  const pulse = 1 + Math.sin(frame/8)*0.015;
  return (
    <AbsoluteFill style={{
      background:'#0A0A0A', color:'white', fontFamily:'Arial, sans-serif',
      padding:90, justifyContent:'center', overflow:'hidden'
    }}>
      <div style={{position:'absolute', top:70, left:90, fontSize:30, letterSpacing:3, color:accent}}>
        {scene.kicker ?? 'AI / MOTION / REMOTION'}
      </div>
      <div style={{transform:`translateY(${y}px) scale(${pulse})`, opacity}}>
        <div style={{fontSize: scene.mode==='hero'?112:86, lineHeight:0.98, fontWeight:900, maxWidth:900}}>
          {scene.text}
        </div>
        <div style={{height:14, background:accent, width:interpolate(frame,[8,28],[0,620],{extrapolateRight:'clamp'}), marginTop:50, borderRadius:20}} />
      </div>
      <div style={{position:'absolute', bottom:70, left:90, right:90, display:'flex', justifyContent:'space-between', fontSize:26, opacity:.55}}>
        <span>9:16 • 30 FPS</span><span>AI REELS STUDIO</span>
      </div>
    </AbsoluteFill>
  );
};

export const Reel: React.FC<{plan:VideoPlan}> = ({plan}) => {
  let from = 0;
  return (
    <AbsoluteFill>
      {plan.scenes.map((scene, i) => {
        const start = from; from += scene.durationInFrames;
        return <Sequence key={i} from={start} durationInFrames={scene.durationInFrames}>
          <SceneView scene={scene} accent={plan.accent}/>
        </Sequence>
      })}
    </AbsoluteFill>
  );
};
