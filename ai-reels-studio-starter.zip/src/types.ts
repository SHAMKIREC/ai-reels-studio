export type Scene = {
  text: string;
  kicker?: string;
  durationInFrames: number;
  mode?: 'hero' | 'cards' | 'quote' | 'number';
};

export type VideoPlan = {
  title: string;
  accent: string;
  scenes: Scene[];
};
