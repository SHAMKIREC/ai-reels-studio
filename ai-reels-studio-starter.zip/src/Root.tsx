import React from 'react';
import {Composition} from 'remotion';
import {Reel} from './Reel';
import type {VideoPlan} from './types';

const demo: VideoPlan = {
  title: 'AI Reels Studio',
  accent: '#A8FF60',
  scenes: [
    {text:'Идея → готовый Reels', kicker:'AI REELS STUDIO', durationInFrames:90, mode:'hero'},
    {text:'Сценарий, ритм и сцены собираются автоматически', durationInFrames:120, mode:'cards'},
    {text:'Remotion превращает план в 9:16 видео', durationInFrames:120, mode:'number'},
    {text:'Один запрос. Один рендер.', durationInFrames:90, mode:'quote'},
  ]
};

export const Root: React.FC = () => (
  <Composition
    id="Reel"
    component={Reel}
    durationInFrames={420}
    fps={30}
    width={1080}
    height={1920}
    defaultProps={{plan: demo}}
    calculateMetadata={({props}) => ({
      durationInFrames: props.plan.scenes.reduce((a,s)=>a+s.durationInFrames,0),
    })}
  />
);
