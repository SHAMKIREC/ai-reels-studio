import express from 'express';
import path from 'node:path';
import fs from 'node:fs/promises';
import {bundle} from '@remotion/bundler';
import {renderMedia, selectComposition} from '@remotion/renderer';
import {makePlan} from './scripts/plan.mjs';

const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static('public'));
app.use('/out', express.static('out'));

let serveUrlPromise;
const getServeUrl = () => serveUrlPromise ??= bundle({entryPoint:path.resolve('src/index.ts')});

app.post('/api/generate', async (req,res) => {
  try {
    const idea = String(req.body?.idea||'').trim();
    if (!idea) return res.status(400).json({error:'Введите идею'});
    const plan = makePlan(idea);
    const serveUrl = await getServeUrl();
    const composition = await selectComposition({serveUrl,id:'Reel',inputProps:{plan}});
    await fs.mkdir('out',{recursive:true});
    const name = `reel-${Date.now()}.mp4`;
    await renderMedia({
      composition, serveUrl, codec:'h264', outputLocation:path.resolve('out',name),
      inputProps:{plan}, chromiumOptions:{gl:'angle'}
    });
    res.json({ok:true, url:`/out/${name}`, plan});
  } catch (e) {
    console.error(e);
    res.status(500).json({error:e?.message || 'Render failed'});
  }
});

const port = process.env.PORT || 3000;
app.listen(port, '0.0.0.0', ()=>console.log(`AI Reels Studio: http://localhost:${port}`));
